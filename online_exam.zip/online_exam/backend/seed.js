// Creates the first admin: email admin@exam.com / password Admin@123
require('dotenv').config();
const mysql = require('mysql2/promise');
const bcrypt = require('bcrypt');

(async () => {
  const db = await mysql.createConnection({
    host: process.env.DB_HOST, port: Number(process.env.DB_PORT) || 3306,
    ssl: process.env.DB_SSL === 'true' ? { rejectUnauthorized: true } : undefined, user: process.env.DB_USER,
    password: process.env.DB_PASS, database: process.env.DB_NAME,
  });
  const hash = await bcrypt.hash('Admin@123', 10);
  const [u] = await db.query(
    "INSERT INTO users (name,email,password,role) VALUES ('Super Admin','admin@exam.com',?, 'admin')", [hash]);
  await db.query("INSERT INTO admins (user_id,employee_no) VALUES (?, 'ADM-001')", [u.insertId]);
  console.log('Admin created: admin@exam.com / Admin@123');
  await db.end();
})();
