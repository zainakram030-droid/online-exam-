// Full demo: node demo.js   (server must be running: npm start)
const B = 'http://localhost:3000/api';
const call = async (method, path, body, token) => {
  const r = await fetch(B + path, {
    method,
    headers: { 'Content-Type': 'application/json', ...(token && { Authorization: 'Bearer ' + token }) },
    body: body && JSON.stringify(body),
  });
  const j = await r.json();
  if (!r.ok) throw new Error(path + ' -> ' + JSON.stringify(j));
  return j;
};
const step = (t) => console.log('\n=== ' + t + ' ===');
const id = Date.now().toString().slice(-6);

(async () => {
  step('1. Admin login');
  const admin = (await call('POST', '/auth/login', { email: 'admin@exam.com', password: 'Admin@123' })).token;
  console.log('Admin logged in');

  step('2. Admin creates Course + Subject and links them');
  const { course_id } = await call('POST', '/courses', { course_name: 'BS Computer Science', course_code: 'BSCS' + id, duration: '4 years', department: 'CS' }, admin);
  const { subject_id } = await call('POST', '/subjects', { subject_name: 'Database Systems', subject_code: 'DB' + id, credit_hours: 3 }, admin);
  await call('POST', `/courses/${course_id}/subjects`, { subject_id }, admin);
  console.log({ course_id, subject_id });

  step('3. Admin creates a Teacher, teacher logs in');
  await call('POST', '/users', { role: 'teacher', name: 'Sir Ali', email: `teacher${id}@exam.com`, password: 'Teacher@123', employee_no: 'T' + id, department: 'CS', qualification: 'MS CS' }, admin);
  const teacher = (await call('POST', '/auth/login', { email: `teacher${id}@exam.com`, password: 'Teacher@123' })).token;
  console.log('Teacher logged in');

  step('4. Teacher creates exam + 2 MCQs and publishes');
  const { exam_id } = await call('POST', '/exams', { subject_id, exam_title: 'DBMS Midterm', exam_date: '2026-10-05', start_time: '09:00:00', end_time: '23:59:00', duration: 30, total_marks: 4, passing_marks: 2 }, teacher);
  const mk = (t, correct) => ({ question_text: t, question_type: 'mcq', marks: 2, correct_answer: correct,
    options: [{ label: 'A', text: 'Option A' }, { label: 'B', text: 'Option B' }, { label: 'C', text: 'Option C' }, { label: 'D', text: 'Option D' }] });
  await call('POST', `/exams/${exam_id}/questions`, mk('What does SQL stand for? (correct = A)', 'A'), teacher);
  await call('POST', `/exams/${exam_id}/questions`, mk('Which key uniquely identifies a row? (correct = C)', 'C'), teacher);
  await call('PATCH', `/exams/${exam_id}/publish`, {}, teacher);
  console.log({ exam_id });

  step('5. Student registers, admin assigns exam');
  const reg = await call('POST', '/auth/register', { name: 'Student Ahmed', email: `student${id}@exam.com`, password: 'Student@123', registration_no: 'REG' + id, gender: 'male', course_id });
  await call('POST', `/exams/${exam_id}/assign`, { student_ids: [reg.student_id] }, admin);
  const student = (await call('POST', '/auth/login', { email: `student${id}@exam.com`, password: 'Student@123' })).token;
  console.log(reg);

  step('6. Student sees exam, starts attempt');
  console.log('My exams:', (await call('GET', '/my-exams', null, student)).map((e) => e.exam_title));
  const att = await call('POST', `/exams/${exam_id}/attempts`, {}, student);
  console.log('Attempt', att.attempt_id, '- questions received (no correct answers shown):', att.questions.length);

  step('7. Student submits (Q1 correct, Q2 wrong) -> auto result');
  const pick = (q, label) => ({ question_id: q.question_id, option_id: q.options.find((o) => o.option_label === label).option_id });
  const result = await call('POST', `/attempts/${att.attempt_id}/submit`, { answers: [pick(att.questions[0], 'A'), pick(att.questions[1], 'B')] }, student);
  console.log(result);

  step('8. Teacher views all results of the exam');
  console.table(await call('GET', `/exams/${exam_id}/results`, null, teacher));
})().catch((e) => console.error('FAILED:', e.message));
