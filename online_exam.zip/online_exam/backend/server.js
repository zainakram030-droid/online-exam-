require('dotenv').config();
const express = require('express');
const mysql = require('mysql2/promise');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

const pool = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  port: Number(process.env.DB_PORT) || 3306,
  ssl: process.env.DB_SSL === 'true' ? { rejectUnauthorized: true } : undefined,
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASS || '',
  database: process.env.DB_NAME || 'online_exam',
  waitForConnections: true,
  connectionLimit: 10,
});

/* ---------- helpers ---------- */
const wrap = (fn) => (req, res) =>
  fn(req, res).catch((e) => {
    console.error(e);
    res.status(e.status || 500).json({ error: e.message });
  });
const fail = (status, message) => Object.assign(new Error(message), { status });

const auth = (...roles) => (req, res, next) => {
  try {
    const token = (req.headers.authorization || '').replace('Bearer ', '');
    req.user = jwt.verify(token, process.env.JWT_SECRET);
    if (roles.length && !roles.includes(req.user.role)) throw 0;
    next();
  } catch {
    res.status(401).json({ error: 'Unauthorized' });
  }
};

function gradeOf(p) {
  if (p >= 85) return 'A';
  if (p >= 75) return 'B';
  if (p >= 65) return 'C';
  if (p >= 50) return 'D';
  return 'F';
}

// create user + role profile in one transaction
async function createUser(role, b) {
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    const hash = await bcrypt.hash(b.password, 10);
    const [u] = await conn.query(
      'INSERT INTO users (name,email,password,phone,role) VALUES (?,?,?,?,?)',
      [b.name, b.email, hash, b.phone || null, role]
    );
    const uid = u.insertId;
    if (role === 'student')
      await conn.query(
        'INSERT INTO students (user_id,registration_no,date_of_birth,gender,address,course_id) VALUES (?,?,?,?,?,?)',
        [uid, b.registration_no, b.date_of_birth || null, b.gender || null, b.address || null, b.course_id || null]
      );
    if (role === 'teacher')
      await conn.query(
        'INSERT INTO teachers (user_id,employee_no,department,qualification) VALUES (?,?,?,?)',
        [uid, b.employee_no, b.department || null, b.qualification || null]
      );
    if (role === 'admin')
      await conn.query('INSERT INTO admins (user_id,employee_no) VALUES (?,?)', [uid, b.employee_no]);
    await conn.commit();
    return uid;
  } catch (e) {
    await conn.rollback();
    throw e;
  } finally {
    conn.release();
  }
}

// get the student_id / teacher_id / admin_id of the logged-in user
async function profileId(user) {
  const t = { student: 'students', teacher: 'teachers', admin: 'admins' }[user.role];
  const [r] = await pool.query(`SELECT ${user.role}_id AS id FROM ${t} WHERE user_id=?`, [user.id]);
  if (!r.length) throw fail(404, 'Profile not found');
  return r[0].id;
}

/* ---------- AUTH ---------- */
// students register themselves
app.post('/api/auth/register', wrap(async (req, res) => {
  const id = await createUser('student', req.body);
  const [s] = await pool.query('SELECT student_id FROM students WHERE user_id=?', [id]);
  res.status(201).json({ user_id: id, student_id: s[0].student_id });
}));

app.post('/api/auth/login', wrap(async (req, res) => {
  const { email, password } = req.body;
  const [r] = await pool.query('SELECT * FROM users WHERE email=? AND status="active"', [email]);
  if (!r.length || !(await bcrypt.compare(password, r[0].password))) throw fail(401, 'Invalid email or password');
  const token = jwt.sign({ id: r[0].user_id, role: r[0].role }, process.env.JWT_SECRET, { expiresIn: '8h' });
  res.json({ token, role: r[0].role, name: r[0].name });
}));

// admin creates teachers / admins
app.post('/api/users', auth('admin'), wrap(async (req, res) => {
  if (!['teacher', 'admin'].includes(req.body.role)) throw fail(400, 'role must be teacher or admin');
  res.status(201).json({ user_id: await createUser(req.body.role, req.body) });
}));

/* ---------- COURSES / SUBJECTS (admin) ---------- */
app.get('/api/courses', auth(), wrap(async (_q, res) => {
  const [r] = await pool.query('SELECT * FROM courses');
  res.json(r);
}));
app.post('/api/courses', auth('admin'), wrap(async (req, res) => {
  const { course_name, course_code, duration, department } = req.body;
  const [r] = await pool.query('INSERT INTO courses (course_name,course_code,duration,department) VALUES (?,?,?,?)',
    [course_name, course_code, duration, department]);
  res.status(201).json({ course_id: r.insertId });
}));
app.post('/api/subjects', auth('admin'), wrap(async (req, res) => {
  const { subject_name, subject_code, credit_hours } = req.body;
  const [r] = await pool.query('INSERT INTO subjects (subject_name,subject_code,credit_hours) VALUES (?,?,?)',
    [subject_name, subject_code, credit_hours]);
  res.status(201).json({ subject_id: r.insertId });
}));
app.post('/api/courses/:id/subjects', auth('admin'), wrap(async (req, res) => {
  await pool.query('INSERT INTO course_subjects (course_id,subject_id) VALUES (?,?)', [req.params.id, req.body.subject_id]);
  res.status(201).json({ ok: true });
}));

/* ---------- EXAMS (teacher) ---------- */
app.post('/api/exams', auth('teacher'), wrap(async (req, res) => {
  const b = req.body;
  const teacher_id = await profileId(req.user);
  const [r] = await pool.query(
    `INSERT INTO examinations (subject_id,teacher_id,exam_title,exam_date,start_time,end_time,duration,total_marks,passing_marks)
     VALUES (?,?,?,?,?,?,?,?,?)`,
    [b.subject_id, teacher_id, b.exam_title, b.exam_date, b.start_time, b.end_time, b.duration, b.total_marks, b.passing_marks]
  );
  res.status(201).json({ exam_id: r.insertId });
}));

app.patch('/api/exams/:id/publish', auth('teacher'), wrap(async (req, res) => {
  await pool.query('UPDATE examinations SET status="published" WHERE exam_id=?', [req.params.id]);
  res.json({ ok: true });
}));

// add a question with its options: { question_text, question_type, marks, correct_answer, options:[{label,text}] }
app.post('/api/exams/:id/questions', auth('teacher'), wrap(async (req, res) => {
  const b = req.body;
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    const [q] = await conn.query(
      'INSERT INTO questions (exam_id,question_text,question_type,marks,correct_answer) VALUES (?,?,?,?,?)',
      [req.params.id, b.question_text, b.question_type || 'mcq', b.marks || 1, b.correct_answer]
    );
    for (const o of b.options || [])
      await conn.query('INSERT INTO options (question_id,option_text,option_label) VALUES (?,?,?)', [q.insertId, o.text, o.label]);
    await conn.commit();
    res.status(201).json({ question_id: q.insertId });
  } catch (e) { await conn.rollback(); throw e; } finally { conn.release(); }
}));

/* ---------- ASSIGNMENT (admin) ---------- */
app.post('/api/exams/:id/assign', auth('admin'), wrap(async (req, res) => {
  const admin_id = await profileId(req.user);
  for (const sid of req.body.student_ids)
    await pool.query('INSERT IGNORE INTO exam_assignments (exam_id,student_id,assigned_by) VALUES (?,?,?)',
      [req.params.id, sid, admin_id]);
  res.status(201).json({ ok: true });
}));

/* ---------- STUDENT ---------- */
app.get('/api/my-exams', auth('student'), wrap(async (req, res) => {
  const sid = await profileId(req.user);
  const [r] = await pool.query(
    `SELECT e.*, a.status AS assignment_status FROM exam_assignments a
     JOIN examinations e ON e.exam_id=a.exam_id
     WHERE a.student_id=? AND e.status='published'`, [sid]);
  res.json(r);
}));

// start attempt -> returns questions WITHOUT correct answers
app.post('/api/exams/:id/attempts', auth('student'), wrap(async (req, res) => {
  const sid = await profileId(req.user);
  const [as] = await pool.query('SELECT * FROM exam_assignments WHERE exam_id=? AND student_id=?', [req.params.id, sid]);
  if (!as.length) throw fail(403, 'Exam not assigned to you');
  if (as[0].status !== 'assigned') throw fail(400, 'You already attempted this exam');
  const [r] = await pool.query('INSERT INTO exam_attempts (exam_id,student_id) VALUES (?,?)', [req.params.id, sid]);
  const [qs] = await pool.query('SELECT question_id,question_text,question_type,marks FROM questions WHERE exam_id=?', [req.params.id]);
  for (const q of qs)
    [q.options] = await pool.query('SELECT option_id,option_label,option_text FROM options WHERE question_id=?', [q.question_id]);
  res.status(201).json({ attempt_id: r.insertId, questions: qs });
}));

// submit answers: { answers:[{question_id, option_id?, answer_text?}] } -> auto-grade -> result
app.post('/api/attempts/:id/submit', auth('student'), wrap(async (req, res) => {
  const sid = await profileId(req.user);
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    const [at] = await conn.query(
      `SELECT at.*, e.duration, e.total_marks, e.passing_marks FROM exam_attempts at
       JOIN examinations e ON e.exam_id=at.exam_id WHERE at.attempt_id=? AND at.student_id=? FOR UPDATE`,
      [req.params.id, sid]);
    if (!at.length) throw fail(404, 'Attempt not found');
    const a = at[0];
    if (a.attempt_status !== 'in_progress') throw fail(400, 'Already submitted');

    const timedOut = (Date.now() - new Date(a.start_time).getTime()) / 60000 > a.duration + 1; // 1 min grace
    let obtained = 0;
    for (const ans of req.body.answers || []) {
      const [q] = await conn.query('SELECT * FROM questions WHERE question_id=? AND exam_id=?', [ans.question_id, a.exam_id]);
      if (!q.length) continue;
      let correct = false;
      if (q[0].question_type === 'short') {
        correct = (ans.answer_text || '').trim().toLowerCase() === q[0].correct_answer.trim().toLowerCase();
      } else if (ans.option_id) {
        const [o] = await conn.query('SELECT option_label FROM options WHERE option_id=? AND question_id=?', [ans.option_id, ans.question_id]);
        correct = o.length && o[0].option_label === q[0].correct_answer;
      }
      const marks = correct ? q[0].marks : 0;
      obtained += marks;
      await conn.query(
        'INSERT INTO student_answers (attempt_id,question_id,option_id,answer_text,marks_obtained) VALUES (?,?,?,?,?)',
        [a.attempt_id, ans.question_id, ans.option_id || null, ans.answer_text || null, marks]);
    }
    await conn.query('UPDATE exam_attempts SET end_time=NOW(), attempt_status=? WHERE attempt_id=?',
      [timedOut ? 'timed_out' : 'submitted', a.attempt_id]);
    await conn.query('UPDATE exam_assignments SET status="attempted" WHERE exam_id=? AND student_id=?', [a.exam_id, sid]);

    const pct = (obtained / a.total_marks) * 100;
    const status = obtained >= a.passing_marks ? 'pass' : 'fail';
    await conn.query(
      'INSERT INTO results (attempt_id,total_marks,obtained_marks,percentage,grade,result_status) VALUES (?,?,?,?,?,?)',
      [a.attempt_id, a.total_marks, obtained, pct.toFixed(2), gradeOf(pct), status]);
    await conn.commit();
    res.json({ total_marks: a.total_marks, obtained_marks: obtained, percentage: +pct.toFixed(2), grade: gradeOf(pct), result_status: status });
  } catch (e) { await conn.rollback(); throw e; } finally { conn.release(); }
}));

app.get('/api/results/me', auth('student'), wrap(async (req, res) => {
  const sid = await profileId(req.user);
  const [r] = await pool.query(
    `SELECT r.*, e.exam_title FROM results r
     JOIN exam_attempts at ON at.attempt_id=r.attempt_id
     JOIN examinations e ON e.exam_id=at.exam_id WHERE at.student_id=?`, [sid]);
  res.json(r);
}));

// teacher/admin: all results of one exam
app.get('/api/exams/:id/results', auth('teacher', 'admin'), wrap(async (req, res) => {
  const [r] = await pool.query(
    `SELECT s.registration_no, u.name, r.obtained_marks, r.total_marks, r.percentage, r.grade, r.result_status
     FROM results r JOIN exam_attempts at ON at.attempt_id=r.attempt_id
     JOIN students s ON s.student_id=at.student_id JOIN users u ON u.user_id=s.user_id
     WHERE at.exam_id=?`, [req.params.id]);
  res.json(r);
}));

app.listen(process.env.PORT || 3000, () => console.log('API running on port', process.env.PORT || 3000));
