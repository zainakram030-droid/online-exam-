-- Online Examination System - MySQL 8 schema (based on the ERD)

-- 1) USER (parent of student / teacher / admin)
CREATE TABLE users (
  user_id    INT AUTO_INCREMENT PRIMARY KEY,
  name       VARCHAR(100) NOT NULL,
  email      VARCHAR(150) NOT NULL UNIQUE,
  password   VARCHAR(255) NOT NULL,            -- bcrypt hash, never plain text
  phone      VARCHAR(20),
  role       ENUM('student','teacher','admin') NOT NULL,
  status     ENUM('active','inactive') NOT NULL DEFAULT 'active'
);

-- 2) COURSE
CREATE TABLE courses (
  course_id    INT AUTO_INCREMENT PRIMARY KEY,
  course_name  VARCHAR(120) NOT NULL,
  course_code  VARCHAR(30)  NOT NULL UNIQUE,
  duration     VARCHAR(50),
  department   VARCHAR(100)
);

-- 3) SUBJECT
CREATE TABLE subjects (
  subject_id    INT AUTO_INCREMENT PRIMARY KEY,
  subject_name  VARCHAR(120) NOT NULL,
  subject_code  VARCHAR(30)  NOT NULL UNIQUE,
  credit_hours  INT
);

-- 4) COURSE_SUBJECT (junction: Course M---M Subject)
CREATE TABLE course_subjects (
  course_subject_id INT AUTO_INCREMENT PRIMARY KEY,
  course_id  INT NOT NULL,
  subject_id INT NOT NULL,
  UNIQUE (course_id, subject_id),
  FOREIGN KEY (course_id)  REFERENCES courses(course_id)  ON DELETE CASCADE,
  FOREIGN KEY (subject_id) REFERENCES subjects(subject_id) ON DELETE CASCADE
);

-- 5) STUDENT (User 1---0..1 Student, Course 1---M Student)
CREATE TABLE students (
  student_id      INT AUTO_INCREMENT PRIMARY KEY,
  user_id         INT NOT NULL UNIQUE,
  registration_no VARCHAR(50) NOT NULL UNIQUE,
  date_of_birth   DATE,
  gender          ENUM('male','female','other'),
  address         VARCHAR(255),
  course_id       INT,
  FOREIGN KEY (user_id)   REFERENCES users(user_id)     ON DELETE CASCADE,
  FOREIGN KEY (course_id) REFERENCES courses(course_id) ON DELETE SET NULL
);

-- 6) TEACHER
CREATE TABLE teachers (
  teacher_id    INT AUTO_INCREMENT PRIMARY KEY,
  user_id       INT NOT NULL UNIQUE,
  employee_no   VARCHAR(50) NOT NULL UNIQUE,
  department    VARCHAR(100),
  qualification VARCHAR(150),
  FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);

-- 7) ADMIN
CREATE TABLE admins (
  admin_id    INT AUTO_INCREMENT PRIMARY KEY,
  user_id     INT NOT NULL UNIQUE,
  employee_no VARCHAR(50) NOT NULL UNIQUE,
  FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);

-- 8) EXAMINATION (Subject 1---M Exam, Teacher 1---M Exam "Creates")
CREATE TABLE examinations (
  exam_id       INT AUTO_INCREMENT PRIMARY KEY,
  subject_id    INT NOT NULL,
  teacher_id    INT NOT NULL,
  exam_title    VARCHAR(150) NOT NULL,
  exam_date     DATE NOT NULL,
  start_time    TIME NOT NULL,
  end_time      TIME NOT NULL,
  duration      INT NOT NULL COMMENT 'minutes',
  total_marks   INT NOT NULL,
  passing_marks INT NOT NULL,
  status        ENUM('draft','published','closed') NOT NULL DEFAULT 'draft',
  FOREIGN KEY (subject_id) REFERENCES subjects(subject_id),
  FOREIGN KEY (teacher_id) REFERENCES teachers(teacher_id)
);

-- 9) EXAM_ASSIGNMENT (Exam 1---M Assignment, Student M---M Exam)
--    assigned_by = admin who assigned (ERD "Assigned To" with Admin)
CREATE TABLE exam_assignments (
  assignment_id INT AUTO_INCREMENT PRIMARY KEY,
  exam_id       INT NOT NULL,
  student_id    INT NOT NULL,
  assigned_by   INT NULL,
  assigned_date DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  status        ENUM('assigned','attempted','expired') NOT NULL DEFAULT 'assigned',
  UNIQUE (exam_id, student_id),
  FOREIGN KEY (exam_id)     REFERENCES examinations(exam_id) ON DELETE CASCADE,
  FOREIGN KEY (student_id)  REFERENCES students(student_id)  ON DELETE CASCADE,
  FOREIGN KEY (assigned_by) REFERENCES admins(admin_id)      ON DELETE SET NULL
);

-- 10) EXAM_ATTEMPT
CREATE TABLE exam_attempts (
  attempt_id     INT AUTO_INCREMENT PRIMARY KEY,
  exam_id        INT NOT NULL,
  student_id     INT NOT NULL,
  start_time     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  end_time       DATETIME NULL,
  attempt_status ENUM('in_progress','submitted','timed_out') NOT NULL DEFAULT 'in_progress',
  FOREIGN KEY (exam_id)    REFERENCES examinations(exam_id) ON DELETE CASCADE,
  FOREIGN KEY (student_id) REFERENCES students(student_id)  ON DELETE CASCADE
);

-- 11) QUESTION
CREATE TABLE questions (
  question_id    INT AUTO_INCREMENT PRIMARY KEY,
  exam_id        INT NOT NULL,
  question_text  TEXT NOT NULL,
  question_type  ENUM('mcq','true_false','short') NOT NULL DEFAULT 'mcq',
  marks          INT NOT NULL DEFAULT 1,
  correct_answer VARCHAR(255) NOT NULL,   -- option label ('A') for mcq, text for short
  FOREIGN KEY (exam_id) REFERENCES examinations(exam_id) ON DELETE CASCADE
);

-- 12) OPTION (Question 1---M Option)
CREATE TABLE options (
  option_id   INT AUTO_INCREMENT PRIMARY KEY,
  question_id INT NOT NULL,
  option_text VARCHAR(500) NOT NULL,
  option_label VARCHAR(5)  NOT NULL,      -- A, B, C, D
  FOREIGN KEY (question_id) REFERENCES questions(question_id) ON DELETE CASCADE
);

-- 13) STUDENT_ANSWER (Attempt 1---M Answer, Answer "Answered By" Question/Option)
CREATE TABLE student_answers (
  answer_id      INT AUTO_INCREMENT PRIMARY KEY,
  attempt_id     INT NOT NULL,
  question_id    INT NOT NULL,
  option_id      INT NULL,
  answer_text    VARCHAR(500) NULL,
  marks_obtained DECIMAL(6,2) NOT NULL DEFAULT 0,
  UNIQUE (attempt_id, question_id),
  FOREIGN KEY (attempt_id)  REFERENCES exam_attempts(attempt_id) ON DELETE CASCADE,
  FOREIGN KEY (question_id) REFERENCES questions(question_id)    ON DELETE CASCADE,
  FOREIGN KEY (option_id)   REFERENCES options(option_id)        ON DELETE SET NULL
);

-- 14) RESULT (Attempt 1---1 Result "Generates")
CREATE TABLE results (
  result_id      INT AUTO_INCREMENT PRIMARY KEY,
  attempt_id     INT NOT NULL UNIQUE,
  total_marks    INT NOT NULL,
  obtained_marks DECIMAL(6,2) NOT NULL,
  percentage     DECIMAL(5,2) NOT NULL,
  grade          VARCHAR(3),
  result_status  ENUM('pass','fail') NOT NULL,
  result_date    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (attempt_id) REFERENCES exam_attempts(attempt_id) ON DELETE CASCADE
);

-- Default admin (password: Admin@123 -> replace hash by running the backend's /api/auth/register or bcrypt yourself)
-- Easier: create first admin through the seed script (node seed.js)
